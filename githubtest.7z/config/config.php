<?php


include('config/connect.php'); //attach connection script

// functions setups

include('function/pre.php'); //attach our pre functions
include('function/template.php'); //attach our template functions
include('function/sandbox.php'); //attach our unsorted functions





?>